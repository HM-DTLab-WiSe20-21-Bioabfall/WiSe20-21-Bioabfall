import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desktop-layout',
  templateUrl: './desktop-layout.component.html',
  styleUrls: ['./desktop-layout.component.scss']
})
export class DesktopLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
