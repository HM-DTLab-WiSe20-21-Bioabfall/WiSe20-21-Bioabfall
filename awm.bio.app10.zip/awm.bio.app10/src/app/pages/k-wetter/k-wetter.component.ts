import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-k-wetter',
  templateUrl: './k-wetter.component.html',
  styleUrls: ['./k-wetter.component.scss']
})
export class KWetterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
