export const environment = {
  production: true,
  apiUrl_nine: 'https://nine.hm.edu/api/v2'
};
